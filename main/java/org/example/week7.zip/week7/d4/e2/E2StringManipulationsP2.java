package org.example.week7.d4.e2;

public class E2StringManipulationsP2 {
    public static void main(String[] args) {
        /*
         *
         * 1. Declare a String variable called 'email' and assign it "john.doe@example.com".
         *
         *
         * 2. Check if the email contains the "@" symbol:
         *
         * 3. To check if the email starts with "info":
         *
         * 4. To check if the email ends with ".com":
         *
         * 5. Use System.out.println to print each boolean result on a new line.
         *
         * Expected Output:
         * true
         * false
         * true
         */

        String email="john.doe@example.com";
        System.out.println(email.contains("@"));
        System.out.println(email.startsWith("info"));
        System.out.println(email.endsWith(".com"));

    }
}
