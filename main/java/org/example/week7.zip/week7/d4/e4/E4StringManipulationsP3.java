package org.example.week7.d4.e4;

public class E4StringManipulationsP3 {
    public static void main(String[] args) {
        // Heads up! This is a tricky one.
// Hint 1: Think about a string containing all these words - what's a famous sentence with 'fox' and 'dog'?
        String word="hello";
        System.out.println("Position of first 'o': " + word.indexOf('o'));
        System.out.println("Position of 'j': " + word.indexOf('j'));

// Hint 2: Remember indexOf() finds single characters using '' quotes, not ""

// Hint 3: For finding words like "jumps", use "" quotes with indexOf()

// Hint 4: To start searching from a specific position, indexOf() can take two arguments

// Hint 5: When searching for something that doesn't exist, what special value should you expect?


    }
}
