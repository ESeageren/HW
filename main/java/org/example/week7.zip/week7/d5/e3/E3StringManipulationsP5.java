package org.example.week7.d5.e3;

import java.awt.*;

public class E3StringManipulationsP5 {
    public static void main(String[] args) {

        /*
         * 1. Create a String variable named phoneNumber with the value "(123) 456-7890".
         * 2. Use the replaceAll() method with the regex to remove all non-digit characters.
         * 3. Assign the result to a variable or update phoneNumber.
         * 4. Print the result using System.out.println.
         *
         * The expected output should be: 1234567890
         */
        String phoneNumber="(123) 456-7890";
        System.out.println(phoneNumber.replaceAll("[^0-9]",""));


    }
}
