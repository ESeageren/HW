package org.example.week7.d5.e1;

public class E1StringManipulationsP4 {
    public static void main(String[] args) {
        /*
         * 1. Create a variable of type String and assign it the value "HelloLearnJavaWorld".
         *
         * 2. Identify the part of the string you need to extract. In this exercise, you need "LearnJava".
         *
         * 3. Determine the starting index:
         *    - Count from the beginning of the string (starting at index 0) until you reach the first character of "LearnJava".
         *
         * 4. Determine the ending index:
         *    - Count from the beginning until just after the last character of "LearnJava".
         *    - Remember: the character at the ending index is not included in the result.
         *
         * 5. Use the substring() method with the starting and ending indices you determined to extract the desired part.
         *
         * 6. Print the extracted substring.
         *
         */
        String dataString="HelloLearnJavaWorld";
        System.out.println(dataString.substring(5, 14));






    }
}
