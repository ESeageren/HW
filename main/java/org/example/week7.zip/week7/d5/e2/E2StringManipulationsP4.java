package org.example.week7.d5.e2;

public class E2StringManipulationsP4 {
    public static void main(String[] args) {
        /*
         * 1. Create a String variable called textMessage and assign it the value "Hey! LMK if you are free.".
         *
         * 2. Use the replace() method to change "LMK" to "Let me know".
         *    - Think about the syntax: textMessage.replace("LMK", "Let me know")
         *
         * 3. Print the result with System.out.println.
         *
         * 4. The expected output should simply be:
         *    Hey! Let me know if you are free.
         */
        String textMessage="Hey! LMK if you are free.";
        System.out.println(textMessage.replace("LMK", "Let me know"));



    }
}
