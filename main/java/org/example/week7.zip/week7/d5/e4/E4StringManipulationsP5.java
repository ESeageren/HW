package org.example.week7.d5.e4;

public class E4StringManipulationsP5 {
    public static void main(String[] args) {
        /*
         * 1. Create a String variable called csvLine and assign it the value:
         *    "John Doe,22,Computer Science,3.8,2025"
         *
         * 2. Use the split() method with a comma (",") as the delimiter to break the string into parts.
         *
         * 3. Store the result in a String array.
         *
         * 4. Use a normal for loop to iterate over the array.
         *
         * 5. Print each element on a new line.
         *
         * These steps will help you extract each field from the CSV line and print them one by one.
         */
        String csvLine="John Doe,22,Computer Science,3.8,2025";
        String [] csvArray=csvLine.split(",");
        for (int i = 0; i < csvArray.length; i++) {
            System.out.println(csvArray[i]);

        }


    }}

