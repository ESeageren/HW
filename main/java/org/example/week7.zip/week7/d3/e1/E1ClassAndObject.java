package org.example.week7.d3.e1;

public class E1ClassAndObject {
    public static void main(String[] args) {
        // Create a class in the same package named 'Student'
        Student student1=new Student();
        student1.name="John";
        student1.roll_no=2;
        System.out.println("Name is " + student1.name + " and roll number is " + student1.roll_no);


        // Declare a String variable named 'name' and an integer variable named 'roll_no'

        // Create an object of the class 'Student'

        // Assign the value "John" to the 'name' variable

        // Assign the value 2 to the 'roll_no' variable

        // Print the values of 'name' and 'roll_no' in the specified format

    }
}
