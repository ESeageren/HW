package org.example.week7.d3.e1;

public class Student {

    String name;
    int roll_no;

}
