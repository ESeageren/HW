package org.example.week7.d3.e2;

import java.util.Locale;

public class E2StringManipulationsP1 {
    public static void main(String[] args) {
    // Create a String variable named 'name' and assign it the value Timmy
        String name="Timmy";
    // Use the length() method to find out how many characters are in the string
        System.out.println("Length of Timmy: " + name.length());
    // Convert the string to uppercase using toUpperCase() and print the result
        System.out.println("Uppercase: " + name.toUpperCase());
    // Convert the string to lowercase using toLowerCase() and print the result
        System.out.println("Lowercase: " + name.toLowerCase());

    }
}
